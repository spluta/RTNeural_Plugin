# Aida X models are already saved in RTNeural format
# they are most likely trained at 48K

