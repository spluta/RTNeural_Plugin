# Chowdhury Models

These are models taken from Jatin Chowdhury's example RTNeural plugin and Chow Centaur. These have a BSD 3-Clause License